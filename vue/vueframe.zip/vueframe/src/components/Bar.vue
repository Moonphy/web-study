<template>
  <div class="bar clearfix">
    <div class="ttv-left">left</div>
    <div class="ttv-right">right</div>
  </div>
</template>

<script>
export default {

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="stylus">
  @import '../assets/stylus/color'
  .bar
    height 40px
    background primary_color
</style>
