/**
 * API统一入口
 *
 */

import nav from '../api/nav.js'
import user from '../api/user.js'

export default {
  nav,
  user
}
