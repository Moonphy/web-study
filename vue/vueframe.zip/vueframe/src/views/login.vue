<template>
  <div class="login">
    <div style="text-align:center">
      <i class="fa fa-exclamation-circle "></i>
      <p style="font-size:16px;">请先登录</p>
    </div>
  </div>
</template>

<style>


</style>
