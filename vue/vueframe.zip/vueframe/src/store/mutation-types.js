// 导航
// 导航列表
export const GET_NAVS = 'GET_NAVS'
// 当前导航
export const CURRENT_NAV = 'CURRENT_NAV'

// loading状态
export const SET_STATE = 'SET_STATE'

export const SET_ROUTER = 'SET_ROUTER'

// 用户
export const GET_USER = 'GET_USER'

export const GET_USERS = 'GET_USERS'

export const ADD_USER = 'ADD_USER'

